package com.haa.ha;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HaApplication {

	public static void main(String[] args) {
		SpringApplication.run(HaApplication.class, args);
	}

}
