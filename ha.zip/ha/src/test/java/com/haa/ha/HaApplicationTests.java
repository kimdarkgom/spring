package com.haa.ha;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HaApplicationTests {

	@Test
	void contextLoads() {
	}

}
